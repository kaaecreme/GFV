#include "project.h"


float convertMeasurement(uint8 byte1, uint8 byte2);
void writeTempToUART(float temp);
void readAndPrint(uint8 adress);
